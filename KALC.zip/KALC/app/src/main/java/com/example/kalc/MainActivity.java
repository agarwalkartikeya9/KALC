package com.example.kalc;

import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Arrays;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    Button b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12,b13,b14,b15,b16,b17,b18;
    TextView t1,t2;
    TextToSpeech ts;
    Vibrator v1;
    char total[]=new char[100];
    int indexButton=0;
    int countAction=0,countOperand=0;
   String combine="";
   int vibrate=80;

  int ans=0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        b1=(Button) findViewById(R.id.button);
        b2=(Button) findViewById(R.id.button2);
        b3=(Button) findViewById(R.id.button3);
        b4=(Button) findViewById(R.id.button4);
        b5=(Button) findViewById(R.id.button5);
        b6=(Button) findViewById(R.id.button6);
        b7=(Button) findViewById(R.id.button7);
        b8=(Button) findViewById(R.id.button8);
        b9=(Button) findViewById(R.id.button9);
        b10=(Button) findViewById(R.id.button10);
        b11=(Button) findViewById(R.id.button11);
        b12=(Button) findViewById(R.id.button12);
        b13=(Button) findViewById(R.id.button13);
        b14=(Button) findViewById(R.id.button14);
        b15=(Button) findViewById(R.id.button15);
        b16=(Button) findViewById(R.id.button16);
        b17=(Button) findViewById(R.id.button17);
        b18=(Button) findViewById(R.id.button18);

        t1=(TextView) findViewById(R.id.textView);
        t2=(TextView) findViewById(R.id.textView2);
        v1=(Vibrator)getSystemService(VIBRATOR_SERVICE);
        ts=new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int i) {
                ts.setLanguage(Locale.ENGLISH);
                ts.setSpeechRate(0.8f);
            }
        });
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                total[indexButton++]='1';
                countOperand++;

                t2.setText("1");
                v1.vibrate(vibrate);

            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                total[indexButton++]='2';
                countOperand++;
                t2.setText("2");
                v1.vibrate(vibrate);

            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                total[indexButton++]='3';
                countOperand++;
                t2.setText("3");
                v1.vibrate(vibrate);


            }
        });
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                total[indexButton++]='4';
                countOperand++;
                t2.setText("4");
                v1.vibrate(vibrate);

            }
        });
        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                total[indexButton++]='5';
                countOperand++;
                t2.setText("5");
                v1.vibrate(vibrate);

            }
        });
        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                total[indexButton++]='6';
                countOperand++;
                t2.setText("6");
                v1.vibrate(vibrate);

            }
        });
        b7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                total[indexButton++]='7';
                countOperand++;
                t2.setText("7");
                v1.vibrate(vibrate);
            }
        });
        b8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                total[indexButton++]='8';
                countOperand++;
                t2.setText("8");
                v1.vibrate(vibrate);

            }
        });
        b9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                total[indexButton++]='9';
                countOperand++;
                t2.setText("9");
                v1.vibrate(20);

            }
        });
        b16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                total[indexButton++]='0';
                countOperand++;
                t2.setText("0");
                v1.vibrate(vibrate);

            }
        });
        b10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                total[indexButton++]='+';
                countAction++;
                t2.setText("+");
                v1.vibrate(vibrate);

            }
        });
        b11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                total[indexButton++]='-';
                countAction++;
                t2.setText("-");
                v1.vibrate(vibrate);

            }
        });
        b12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                total[indexButton++]='*';
                countAction++;
                t2.setText("*");
                v1.vibrate(vibrate);
            }
        });
        b13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                total[indexButton++]='/';
                countAction++;
                t2.setText("/");
                v1.vibrate(vibrate);

            }
        });
        b14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                total[indexButton++]='%';
                countAction++;
                t2.setText("%");
                v1.vibrate(vibrate);
            }


        });
        b17.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                 t2.setText("^2");
                 ans=ans*ans;
                 String s=Integer.toString(ans);
                 t1.setText(s);
                v1.vibrate(vibrate);

            }
        });
        b15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                v1.vibrate(vibrate);
                 combine= new String(total);
                combine=combine.substring(0,indexButton);
                char actionV[]=new char[countAction];
                String numStr[]=combine.split("[-+/%*]+");
                int index=0;
                char ch;
                for(int i=0;i<indexButton;i++)
                {
                 ch=combine.charAt(i);
                 if(Character.isDigit(ch))continue;
                 else
                 {
                     actionV[index++]=ch;
                 }
                }

                int numInt[]=new int[numStr.length];
                for(int i=0;i<numInt.length;i++)
                {
                    numInt[i]=Integer.parseInt(numStr[i]);
                }
                ans=numInt[0];
                for(int i=0;i<countAction;i++) {
                    if (actionV[i] == '+') ans = ans + numInt[i + 1];
                    else if(actionV[i]=='-')ans=ans-numInt[i+1];
                    else if(actionV[i]=='*')ans=ans*numInt[i+1];
                    else if(actionV[i]=='/')ans=ans/numInt[i+1];
                    else if(actionV[i]=='%')ans=ans%numInt[i+1];



                }
                String s1=Integer.toString(ans);
                ts.speak("RESULT"+s1,TextToSpeech.QUEUE_FLUSH,null);
                t1.setText(s1);

       }
         });
        b18.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                v1.vibrate(vibrate);
                Arrays.fill(total,'\0');
                countAction=0;
                countOperand=0;
                indexButton=0;
                String value="RESULT:";
                t1.setText(value);
                String value2="OPERATION:";
                t2.setText(value2);
            }
        });

}
}